.. image:: https://travis-ci.org/fabianp/mord.svg?branch=master
    :target: https://travis-ci.org/fabianp/mord

mord: ordinal regression in Python
==================================

Collection of Ordinal Regression algorithms in Python, following a scikit-learn compatible API.

Docs: https://pythonhosted.org/mord/

Github repo: http://github.com/fabianp/mord


